import tkinter as tk
import tkinter.font as tfont


from tkinter import ttk

window=tk.Tk()
window.title("My Application")

custom_font =tk.font.Font(family='Helvetica', size=12, weight='bold')

window.minsize(width=400, height=300)


label= ttk.Label(text="Hello world!!\n Have a nice day",font=custom_font)
#label.pack(expand=True)
label.pack()


label["text"]="How are You?"
label.config(text="hi friend")



def function_button():
    input_text = user_input.get()
    label.config(text=input_text)




# Taking user input using Entry

from tkinter import Entry

#user_input = Entry(width=40,show="*")

user_input = ttk.Entry(width=40)
user_input.pack()
user_input.get()


# Buttons

button = ttk.Button(window,text="Click me",command =function_button )
button.pack()

Quit_buttton = ttk.Button(window,text="Quit",command=window.destroy)
Quit_buttton.pack()

window.mainloop()
