import tkinter as tk
import tkinter.font as tfont
from gc import enable

from tkinter import ttk
from turtledemo.sorting_animate import enable_keys

window=tk.Tk()
window.title("My Application")

custom_font =tk.font.Font(family='Helvetica', size=12, weight='bold')

window.minsize(width=400, height=300)


label= ttk.Label(text="Hello world!!\n Have a nice day",font=custom_font,padding=15)
#label.pack(expand=True)
label.pack()


label["text"]="How are You?"
label.config(text="Hi friend")



def function_button():
    input_text = user_input.get()
    label.config(text=input_text)




# Taking user input using Entry

from tkinter import Entry

#user_input = Entry(width=40,show="*")

user_input = ttk.Entry(width=40)
user_input.pack()
user_input.get()


# Buttons

button = ttk.Button(window,text="Click me",command =function_button )
button.pack()

Quit_buttton = ttk.Button(window,text="Quit",command=window.destroy)  # Quit button
Quit_buttton.pack(pady=10)


sep=ttk.Separator(orient="horizontal")  # used to separate line the distance b/w button and text box
sep.pack(fill="x")


text= tk.Text(width=20,height=5)
text.pack(pady=10)
text.focus()  # for cursor

text.insert("1.0","Hello friend")  # default text in box
text["state"] = "normal"

def text_function():
    text_data = text.get("1.0", "end")
    print(text_data)


text_button = ttk.Button(window,text="Get text",command=text_function)
text_button.pack()


# Creating Check Box in window

check_option = tk.StringVar()


def check_option_task ():
    print(check_option.get())

check_button = ttk.Checkbutton(text="Agree with the terms & conditions",variable=check_option,
                               command=check_option_task,onvalue="Yes",offvalue="No")
check_button.pack()



# Radio Button

radio_value = tk.StringVar()


def radio_value_task ():
    print(radio_value.get())

option_1 = ttk.Radiobutton(text="Male",variable=radio_value,value="Male",
                           command=radio_value_task)
option_1.pack()

option_2 = ttk.Radiobutton(text="Female",variable=radio_value,value="Female",
                           command=radio_value_task)
option_2.pack()


# Combobox

selected_country = tk.StringVar()
countries = ttk.Combobox(textvariable=selected_country,
                         values=("Canada", "United Kingdom", "United States","Russia"))
countries["state"] = "readonly"
countries.pack()


def display_country(event):
    msg = f'Selected country: {selected_country.get()}\n'
    country_label = ttk.Label(text=msg)
    country_label.pack()
    #print(f"Selected country: {selected_country.get()}")


countries.bind("<<ComboboxSelected>>",display_country)


# Listbox

food_items = ("Pizza","Burger","Garlic bread","Nachos","salad","Burger")
fav_food = tk.StringVar(value=food_items)

food_list = tk.Listbox(window,width=10,height=5,listvariable=fav_food,selectmode="extended")
food_list.pack()


def get_fav_food(event):
    food_indexes = food_list.curselection()
    for i in food_indexes:
        print(food_items[i])

food_list.bind("<<ListboxSelect>>",get_fav_food)


#  Spinbox

counter = tk.IntVar(value=10)


def get_spin_box_value():
    print(f'Current SpinBox value: {counter.get()}\n')


spin_box = ttk.Spinbox(from_=0,to=20,width=10,textvariable=counter,wrap=True,command=get_spin_box_value)
spin_box.pack() # values = tuple(range(5,100,5)  we can use instead of from and to values in above


print(f'Initial spinbox Value: {spin_box.get()}')

window.mainloop()
