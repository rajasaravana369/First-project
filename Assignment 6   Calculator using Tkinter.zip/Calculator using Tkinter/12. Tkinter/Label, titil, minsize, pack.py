import tkinter as tk

import tkinter.font as tkFont
# TK

window=tk.Tk()
window.title("My Application")


window.minsize(width=400, height=300)


label= tk.Label(text="Hello world!!\n Have a nice day")
label.pack(side="bottom")
label.pack(expand=True)
#label= tk.Label(text="Hello world!!\n Have a nice day",font=("Arial",20,"bold"))


custom_font =tk.font.Font(family='Helvetica', size=12, weight='bold')
#label= tk.Label(text="Hello world!!\n Have a nice day", font=custom_font)

#label.config(font=("Courier New",25,"underline"))
label.config(font=("Courier New",25))


window.mainloop()
