import tkinter as tk

# Tk

window = tk.Tk()

window.mainloop()