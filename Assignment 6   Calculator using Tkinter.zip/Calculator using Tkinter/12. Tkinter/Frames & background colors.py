import tkinter as tk
from tkinter import ttk
import tkinter.font as tfont

window = tk.Tk()
window.title("My Interactive Window")

my_frame = ttk.Frame()
my_frame.pack(side="left", fill="both", expand=True)


t=tk.font.Font(family='Helvetica', size=12, weight='bold')

label1 = tk.Label(my_frame, text="Hello World",bg="red")
label1.pack(side="top",fill="both",expand=True)
#label1.pack(side="left",fill="y",expand=True)

label2 = tk.Label( text="What is your name?",bg="green")
label2.pack(side="top",fill="both",expand=True)


label3 = tk.Label( text="How are you?",bg="blue")
#label3.pack(side="left")
label3.pack(side="top",fill="both",expand=True)


window.mainloop()





