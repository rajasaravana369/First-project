import tkinter as tk
import tkinter.font as tfont
from gc import enable

from tkinter import ttk
from turtledemo.sorting_animate import enable_keys

window=tk.Tk()
window.title("My Application")

custom_font =tk.font.Font(family='Helvetica', size=12, weight='bold')

window.minsize(width=400, height=300)


label= ttk.Label(text="Hello world!!\n Have a nice day",font=custom_font,padding=15)
#label.pack(expand=True)
label.pack()


label["text"]="How are You?"
label.config(text="Hi friend")



def function_button():
    input_text = user_input.get()
    label.config(text=input_text)




# Taking user input using Entry

from tkinter import Entry

#user_input = Entry(width=40,show="*")

user_input = ttk.Entry(width=40)
user_input.pack()
user_input.get()


# Buttons

button = ttk.Button(window,text="Click me",command =function_button )
button.pack()

Quit_buttton = ttk.Button(window,text="Quit",command=window.destroy)  # Quit button
Quit_buttton.pack(pady=10)


sep=ttk.Separator(orient="horizontal")  # used to separate line the distance b/w button and text box
sep.pack(fill="x")


text= tk.Text(width=20,height=5)
text.pack(pady=10)
text.focus()  # for cursor

text.insert("1.0","Hello friend")  # default text in box
text["state"] = "normal"

def text_function():
    text_data = text.get("1.0", "end")
    print(text_data)


text_button = ttk.Button(window,text="Get text",command=text_function)
text_button.pack()


# Creating Check Box in window

check_option = tk.StringVar()


def check_option_task ():
    print(check_option.get(),type(check_option.get()))

check_button = ttk.Checkbutton(text="Agree with the terms & conditions",variable=check_option,
                               command=check_option_task,onvalue="Yes",offvalue="No")
check_button.pack()



window.mainloop()