import tkinter as tk

import tkinter.font as tkFont
# TK

window=tk.Tk()
window.title("My Application")

custom_font =tk.font.Font(family='Helvetica', size=12, weight='bold')

window.minsize(width=400, height=300)


label= tk.Label(text="Hello world!!\n Have a nice day",font=custom_font)
#label.pack(expand=True)
label.pack()


label["text"]="How are You?"
label.config(text="hi friend")




# Buttons

counter = 0
def function_button():
    global counter
    label.config(text=f"The Button got clicked {counter} times")
    counter += 1

# Buttons

button = tk.Button(window,text="Click me",command =function_button )
button.pack(side="bottom")



window.mainloop()



