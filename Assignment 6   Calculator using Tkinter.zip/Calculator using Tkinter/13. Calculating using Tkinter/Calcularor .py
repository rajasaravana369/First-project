# step 1: importing

from tkinter import *

# step 2 : GUI interaction

window = Tk()
window.geometry("300x380")
window.title("Calculator")

# step 3: adding inputs

# Entry box at the top
entry = Entry(window, width=25, font=("Arial", 14), justify="right")
entry.place(x=10, y=10, width=280, height=40)

# Function to handle button clicks
def click_button(value):
    entry.insert(END, value)

def clear_entry():
    entry.delete(0, END)

def evaluate_expression():
    # Get the text from the entry box
    expression = entry.get()

    # Try to find which operator is inside the expression
    if "+" in expression:
        numbers = expression.split("+")
        result = int(numbers[0]) + int(numbers[1])
    elif "-" in expression:
        numbers = expression.split("-")
        result = int(numbers[0]) - int(numbers[1])
    elif "*" in expression:
        numbers = expression.split("*")
        result = int(numbers[0]) * int(numbers[1])
    elif "/" in expression:
        numbers = expression.split("/")
        # Handle division carefully
        if int(numbers[1]) == 0:
            result = "Error (divide by zero)"
        else:
            result = int(numbers[0]) / int(numbers[1])
    else:
        result = "Error"

    # Clear the entry and show the result
    entry.delete(0, END)
    entry.insert(END, str(result))

# Row 1
b = Button(window, text="1", width=6, command=lambda: click_button("1"))
b.place(x=10, y=70)
b = Button(window, text="2", width=6, command=lambda: click_button("2"))
b.place(x=70, y=70)
b = Button(window, text="3", width=6, command=lambda: click_button("3"))
b.place(x=130, y=70)
b = Button(window, text="+", width=6, command=lambda: click_button("+"))
b.place(x=190, y=70)

# Row 2
b = Button(window, text="4", width=6, command=lambda: click_button("4"))
b.place(x=10, y=120)
b = Button(window, text="5", width=6, command=lambda: click_button("5"))
b.place(x=70, y=120)
b = Button(window, text="6", width=6, command=lambda: click_button("6"))
b.place(x=130, y=120)
b = Button(window, text="-", width=6, command=lambda: click_button("-"))
b.place(x=190, y=120)

# Row 3
b = Button(window, text="7", width=6, command=lambda: click_button("7"))
b.place(x=10, y=170)
b = Button(window, text="8", width=6, command=lambda: click_button("8"))
b.place(x=70, y=170)
b = Button(window, text="9", width=6, command=lambda: click_button("9"))
b.place(x=130, y=170)
b = Button(window, text="*", width=6, command=lambda: click_button("*"))
b.place(x=190, y=170)

# Row 4
b = Button(window, text="0", width=6, command=lambda: click_button("0"))
b.place(x=70, y=220)
b = Button(window, text="=", width=6, command=evaluate_expression)
b.place(x=130, y=220)
b = Button(window, text="/", width=6, command=lambda: click_button("/"))
b.place(x=190, y=220)

# Clear button at bottom
b = Button(window, text="Clear", width=28, command=clear_entry)
b.place(x=10, y=280)






# Step 4 : mainloop
mainloop()


